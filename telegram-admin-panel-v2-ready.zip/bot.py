import sqlite3
from telegram import Update
from telegram.ext import ApplicationBuilder, ChatJoinRequestHandler, ChatMemberHandler, ContextTypes
from config import TOKEN

conn = sqlite3.connect("database.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS logs (
    user_id INTEGER,
    username TEXT,
    group_id INTEGER,
    type TEXT,
    status TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_name TEXT,
    group_id INTEGER
)
""")

conn.commit()

async def join_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.chat_join_request.from_user
    group_id = update.chat_join_request.chat.id

    cursor.execute("INSERT INTO logs VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)",
                   (user.id, user.username, group_id, "join", "pending"))
    conn.commit()

async def member_update(update: Update, context: ContextTypes.DEFAULT_TYPE):
    member = update.chat_member
    if member.new_chat_member.status == "left":
        cursor.execute("INSERT INTO logs VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)",
                       (member.from_user.id,
                        member.from_user.username,
                        member.chat.id,
                        "leave",
                        "done"))
        conn.commit()

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(ChatJoinRequestHandler(join_request))
app.add_handler(ChatMemberHandler(member_update, ChatMemberHandler.CHAT_MEMBER))

print("Bot Running...")
app.run_polling()
