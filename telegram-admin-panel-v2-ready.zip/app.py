from flask import Flask, render_template, request, redirect, session
import sqlite3
from telegram import Bot
from config import TOKEN, ADMIN_PASSWORD
import threading
import time

bot = Bot(token=TOKEN)
app = Flask(__name__)
app.secret_key = "supersecretkey"

def db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/", methods=["GET","POST"])
def login():
    if request.method == "POST":
        if request.form["password"] == ADMIN_PASSWORD:
            session["admin"] = True
            return redirect("/dashboard")
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if "admin" not in session:
        return redirect("/")
    conn = db()
    logs = conn.execute("SELECT * FROM logs ORDER BY timestamp DESC").fetchall()
    groups = conn.execute("SELECT * FROM groups").fetchall()
    joins = conn.execute("SELECT COUNT(*) FROM logs WHERE type='join'").fetchone()[0]
    leaves = conn.execute("SELECT COUNT(*) FROM logs WHERE type='leave'").fetchone()[0]
    return render_template("dashboard.html", logs=logs, joins=joins, leaves=leaves, groups=groups)

@app.route("/add_group", methods=["POST"])
def add_group():
    if "admin" not in session:
        return redirect("/")
    name = request.form["group_name"]
    group_id = request.form["group_id"]
    conn = db()
    conn.execute("INSERT INTO groups (group_name, group_id) VALUES (?, ?)",
                 (name, group_id))
    conn.commit()
    return redirect("/dashboard")

@app.route("/approve/<int:user_id>/<int:group_id>")
def approve(user_id, group_id):
    def delayed():
        time.sleep(5)
        bot.approve_chat_join_request(chat_id=group_id, user_id=user_id)
    threading.Thread(target=delayed).start()

    conn = db()
    conn.execute("UPDATE logs SET status='approved' WHERE user_id=?", (user_id,))
    conn.commit()
    return redirect("/dashboard")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)
